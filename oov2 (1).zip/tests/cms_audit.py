import urllib.request
import urllib.parse
import urllib.error
import json
import http.cookiejar
import re

BASE_URL = 'http://127.0.0.1:3000'

def run_cms_audit():
    results = {}
    print("==================================================")
    print("LIVE CMS VERIFICATION & AUDIT RUNNER")
    print("==================================================")

    # 1. Admin login route check
    print("\n1. AUDITING ADMIN LOGIN ROUTES & CREDENTIALS...")
    req = urllib.request.Request(f"{BASE_URL}/admin/login", headers={'User-Agent': 'Audit-Bot'})
    try:
        res = urllib.request.urlopen(req, timeout=10)
        code = res.getcode()
        html = res.read().decode('utf-8')
        has_login_form = 'Admin Portal' in html or 'password' in html.lower() or 'sign in' in html.lower()
        results['admin_login_page'] = {'code': code, 'form_present': has_login_form}
        print(f"✓ /admin/login HTTP {code} (Form detected: {has_login_form})")
    except Exception as e:
        results['admin_login_page'] = {'error': str(e)}
        print(f"✗ /admin/login failed: {e}")

    # Test invalid credentials
    invalid_payload = json.dumps({'email': 'invalid@test.com', 'password': 'WrongPassword123'}).encode('utf-8')
    req_inv = urllib.request.Request(f"{BASE_URL}/api/auth/login", data=invalid_payload, headers={'Content-Type': 'application/json'}, method='POST')
    try:
        urllib.request.urlopen(req_inv, timeout=10)
        results['invalid_login_rejected'] = False
    except urllib.error.HTTPError as e:
        results['invalid_login_rejected'] = (e.code == 401)
        print(f"✓ Invalid credentials rejected with HTTP {e.code}")

    # Test Super Admin login
    admin_payload = json.dumps({'email': 'admin@oliveorange.tech', 'password': 'OliveOrange@Admin2026!'}).encode('utf-8')
    req_adm = urllib.request.Request(f"{BASE_URL}/api/auth/login", data=admin_payload, headers={'Content-Type': 'application/json'}, method='POST')
    res_adm = urllib.request.urlopen(req_adm, timeout=10)
    admin_auth = json.loads(res_adm.read().decode('utf-8'))
    admin_token = admin_auth.get('token')
    results['super_admin_login'] = {'ok': admin_auth.get('ok'), 'role': admin_auth.get('user', {}).get('role')}
    print(f"✓ Super Admin login successful: token acquired, role={admin_auth.get('user', {}).get('role')}")

    # Test Operations Admin login
    ops_payload = json.dumps({'email': 'operations@oliveorange.tech', 'password': 'OliveOrange@Ops2026!'}).encode('utf-8')
    req_ops = urllib.request.Request(f"{BASE_URL}/api/auth/login", data=ops_payload, headers={'Content-Type': 'application/json'}, method='POST')
    res_ops = urllib.request.urlopen(req_ops, timeout=10)
    ops_auth = json.loads(res_ops.read().decode('utf-8'))
    ops_token = ops_auth.get('token')
    results['ops_admin_login'] = {'ok': ops_auth.get('ok'), 'role': ops_auth.get('user', {}).get('role')}
    print(f"✓ Operations Admin login successful: role={ops_auth.get('user', {}).get('role')}")

    # Test Editor login
    editor_payload = json.dumps({'email': 'editor@oliveorange.tech', 'password': 'OliveOrange@Editor2026!'}).encode('utf-8')
    req_ed = urllib.request.Request(f"{BASE_URL}/api/auth/login", data=editor_payload, headers={'Content-Type': 'application/json'}, method='POST')
    res_ed = urllib.request.urlopen(req_ed, timeout=10)
    editor_auth = json.loads(res_ed.read().decode('utf-8'))
    editor_token = editor_auth.get('token')
    results['editor_login'] = {'ok': editor_auth.get('ok'), 'role': editor_auth.get('user', {}).get('role')}
    print(f"✓ Content Editor login successful: role={editor_auth.get('user', {}).get('role')}")

    # Test /admin page access with admin token
    req_admin_page = urllib.request.Request(f"{BASE_URL}/admin", headers={'Authorization': f'Bearer {admin_token}'})
    res_admin_page = urllib.request.urlopen(req_admin_page, timeout=10)
    print(f"✓ /admin HTTP {res_admin_page.getcode()}")

    # -------------------------------------------------------------------------
    # 2 & 3 & 11. REAL CRUD TEST ON BLOG CMS + PUBLIC BLOG INTEGRATION
    # -------------------------------------------------------------------------
    print("\n2. PERFORMING END-TO-END BLOG CMS CRUD TEST...")
    crud_slug = f"audit-test-article-{int(urllib.request.time.time())}"
    editor_headers = {'Authorization': f'Bearer {editor_token}', 'Content-Type': 'application/json'}
    admin_headers = {'Authorization': f'Bearer {admin_token}', 'Content-Type': 'application/json'}

    # 1. CREATE DRAFT
    create_body = json.dumps({
        'title': 'Audit Test Article for Verification',
        'slug': crud_slug,
        'excerpt': 'Temporary test article for CMS verification audit.',
        'content': 'This is full markdown test content for the blog post verification.',
        'category': 'AI Solutions & Automation',
        'status': 'draft',
        'author': 'Lead Auditor',
    }).encode('utf-8')
    req_create = urllib.request.Request(f"{BASE_URL}/api/posts", data=create_body, headers=editor_headers, method='POST')
    res_create = urllib.request.urlopen(req_create, timeout=10)
    created_data = json.loads(res_create.read().decode('utf-8'))
    print(f"✓ 1. CREATE DRAFT: HTTP {res_create.getcode()}, status={created_data.get('post', {}).get('status')}")

    # Verify draft in CMS list
    req_get_draft = urllib.request.Request(f"{BASE_URL}/api/posts?slug={crud_slug}&includeDrafts=true", headers=editor_headers)
    res_get_draft = urllib.request.urlopen(req_get_draft, timeout=10)
    draft_fetched = json.loads(res_get_draft.read().decode('utf-8'))
    assert draft_fetched.get('post', {}).get('status') == 'draft'
    print("✓ 2. VERIFY DRAFT EXISTS in CMS: Confirmed draft exists.")

    # Verify draft is NOT public on /blog/[slug]
    try:
        urllib.request.urlopen(f"{BASE_URL}/blog/{crud_slug}", timeout=10)
        draft_public = True
    except urllib.error.HTTPError as e:
        draft_public = False
        print(f"✓ 3. VERIFY DRAFT IS NOT PUBLIC: /blog/{crud_slug} correctly returned HTTP {e.code}")
    assert not draft_public, "FAILURE: Draft article was publicly visible!"

    # 4. EDIT DRAFT
    edit_body = json.dumps({
        'targetSlug': crud_slug,
        'title': 'Audit Test Article — Edited and Revised',
        'excerpt': 'Revised excerpt for audit verification test.',
    }).encode('utf-8')
    req_edit = urllib.request.Request(f"{BASE_URL}/api/posts", data=edit_body, headers=editor_headers, method='PUT')
    res_edit = urllib.request.urlopen(req_edit, timeout=10)
    edited_data = json.loads(res_edit.read().decode('utf-8'))
    print(f"✓ 4. EDIT ARTICLE: HTTP {res_edit.getcode()}, title={edited_data.get('post', {}).get('title')}")

    # 5. PUBLISH ARTICLE
    pub_body = json.dumps({'slug': crud_slug}).encode('utf-8')
    req_pub = urllib.request.Request(f"{BASE_URL}/api/posts", data=pub_body, headers=editor_headers, method='PATCH')
    res_pub = urllib.request.urlopen(req_pub, timeout=10)
    pub_data = json.loads(res_pub.read().decode('utf-8'))
    print(f"✓ 5. PUBLISH ARTICLE: HTTP {res_pub.getcode()}, status={pub_data.get('post', {}).get('status')}")

    # 6. VERIFY PUBLIC URL
    res_public_view = urllib.request.urlopen(f"{BASE_URL}/blog/{crud_slug}", timeout=10)
    public_html = res_public_view.read().decode('utf-8')
    has_title = 'Audit Test Article — Edited and Revised' in public_html
    print(f"✓ 6. VERIFY PUBLIC URL: /blog/{crud_slug} HTTP {res_public_view.getcode()} (Contains edited title: {has_title})")
    assert has_title, "FAILURE: Published article title not rendered on public page!"

    # 7. UNPUBLISH ARTICLE
    req_unpub = urllib.request.Request(f"{BASE_URL}/api/posts", data=pub_body, headers=editor_headers, method='PATCH')
    res_unpub = urllib.request.urlopen(req_unpub, timeout=10)
    unpub_data = json.loads(res_unpub.read().decode('utf-8'))
    print(f"✓ 7. UNPUBLISH ARTICLE: HTTP {res_unpub.getcode()}, status={unpub_data.get('post', {}).get('status')}")

    # 8. VERIFY PUBLIC URL IS NO LONGER PUBLIC
    try:
        urllib.request.urlopen(f"{BASE_URL}/blog/{crud_slug}", timeout=10)
        unpub_accessible = True
    except urllib.error.HTTPError as e:
        unpub_accessible = False
        print(f"✓ 8. VERIFY UNPUBLISHED DISAPPEARS: /blog/{crud_slug} returned HTTP {e.code}")
    assert not unpub_accessible, "FAILURE: Unpublished article is still publicly accessible!"

    # 9. DELETE ARTICLE
    req_del = urllib.request.Request(f"{BASE_URL}/api/posts?slug={crud_slug}", headers=editor_headers, method='DELETE')
    res_del = urllib.request.urlopen(req_del, timeout=10)
    print(f"✓ 9. DELETE ARTICLE: HTTP {res_del.getcode()}")

    # 10. VERIFY DELETION IN CMS
    try:
        req_verify_del = urllib.request.Request(f"{BASE_URL}/api/posts?slug={crud_slug}&includeDrafts=true", headers=editor_headers)
        urllib.request.urlopen(req_verify_del, timeout=10)
        del_exists = True
    except urllib.error.HTTPError as e:
        del_exists = False
        print(f"✓ 10. VERIFY DELETION IN CMS: /api/posts correctly returned HTTP {e.code}")
    assert not del_exists, "FAILURE: Deleted article still exists in CMS!"

    # -------------------------------------------------------------------------
    # 4. CATEGORY CMS AUDIT
    # -------------------------------------------------------------------------
    print("\n3. AUDITING CATEGORY CMS...")
    test_cat_slug = f"audit-category-{int(urllib.request.time.time())}"
    cat_create_body = json.dumps({
        'name': 'Audit Verification Category',
        'slug': test_cat_slug,
        'description': 'Category created for audit verification.',
        'active': True,
    }).encode('utf-8')
    req_cat_create = urllib.request.Request(f"{BASE_URL}/api/categories", data=cat_create_body, headers=editor_headers, method='POST')
    res_cat_create = urllib.request.urlopen(req_cat_create, timeout=10)
    print(f"✓ Create Category: HTTP {res_cat_create.getcode()}")

    cat_edit_body = json.dumps({
        'targetSlug': test_cat_slug,
        'name': 'Audit Verification Category Updated',
    }).encode('utf-8')
    req_cat_edit = urllib.request.Request(f"{BASE_URL}/api/categories", data=cat_edit_body, headers=editor_headers, method='PUT')
    res_cat_edit = urllib.request.urlopen(req_cat_edit, timeout=10)
    print(f"✓ Edit Category: HTTP {res_cat_edit.getcode()}")

    # Public category page test
    res_cat_public = urllib.request.urlopen(f"{BASE_URL}/blog/category/{test_cat_slug}", timeout=10)
    print(f"✓ Public Category Page: /blog/category/{test_cat_slug} HTTP {res_cat_public.getcode()}")

    # Delete category
    req_cat_del = urllib.request.Request(f"{BASE_URL}/api/categories?slug={test_cat_slug}", headers=editor_headers, method='DELETE')
    res_cat_del = urllib.request.urlopen(req_cat_del, timeout=10)
    print(f"✓ Delete Category: HTTP {res_cat_del.getcode()}")

    # -------------------------------------------------------------------------
    # 5. MEDIA CMS AUDIT
    # -------------------------------------------------------------------------
    print("\n4. AUDITING MEDIA CMS...")
    # View media
    req_media_list = urllib.request.Request(f"{BASE_URL}/api/media", headers=editor_headers)
    res_media_list = urllib.request.urlopen(req_media_list, timeout=10)
    media_data = json.loads(res_media_list.read().decode('utf-8'))
    media_count = len(media_data.get('media', []))
    print(f"✓ View Media Library: HTTP {res_media_list.getcode()} (Found {media_count} assets)")

    # Add media item
    add_media_body = json.dumps({
        'url': 'https://images.unsplash.com/photo-1518770660439-4636190af475',
        'fileName': 'audit-test-chip.jpg',
        'altText': 'Audit Test Silicon Microchip',
        'mimeType': 'image/jpeg',
        'size': 250000,
    }).encode('utf-8')
    req_add_media = urllib.request.Request(f"{BASE_URL}/api/media", data=add_media_body, headers=editor_headers, method='POST')
    res_add_media = urllib.request.urlopen(req_add_media, timeout=10)
    added_media = json.loads(res_add_media.read().decode('utf-8'))
    media_id = added_media.get('item', {}).get('id')
    print(f"✓ Add Media Asset: HTTP {res_add_media.getcode()} (id={media_id})")

    # Update metadata
    patch_media_body = json.dumps({'id': media_id, 'altText': 'Updated Alt Text for Audit'}).encode('utf-8')
    req_patch_media = urllib.request.Request(f"{BASE_URL}/api/media", data=patch_media_body, headers=editor_headers, method='PATCH')
    res_patch_media = urllib.request.urlopen(req_patch_media, timeout=10)
    print(f"✓ Update Media Metadata: HTTP {res_patch_media.getcode()}")

    # Delete media
    req_del_media = urllib.request.Request(f"{BASE_URL}/api/media?id={media_id}", headers=editor_headers, method='DELETE')
    res_del_media = urllib.request.urlopen(req_del_media, timeout=10)
    print(f"✓ Delete Media Asset: HTTP {res_del_media.getcode()}")

    # -------------------------------------------------------------------------
    # 6. TEAM CMS AUDIT
    # -------------------------------------------------------------------------
    print("\n5. AUDITING TEAM CMS...")
    # Add team member (Admin)
    team_body = json.dumps({
        'name': 'Aarav Patel',
        'designation': 'Lead Automation Specialist',
        'bio': 'Operational workflows and ERP architecture engineer.',
        'isActive': True,
    }).encode('utf-8')
    req_team_add = urllib.request.Request(f"{BASE_URL}/api/team", data=team_body, headers=admin_headers, method='POST')
    res_team_add = urllib.request.urlopen(req_team_add, timeout=10)
    team_member = json.loads(res_team_add.read().decode('utf-8'))
    team_id = team_member.get('member', {}).get('id')
    print(f"✓ Add Team Member: HTTP {res_team_add.getcode()} (id={team_id})")

    # Edit / Deactivate team member
    team_update_body = json.dumps({
        'id': team_id,
        'isActive': False,
        'designation': 'Principal Automation Architect',
    }).encode('utf-8')
    req_team_update = urllib.request.Request(f"{BASE_URL}/api/team", data=team_update_body, headers=admin_headers, method='PUT')
    res_team_update = urllib.request.urlopen(req_team_update, timeout=10)
    print(f"✓ Edit/Deactivate Team Member: HTTP {res_team_update.getcode()}")

    # Delete team member
    req_team_del = urllib.request.Request(f"{BASE_URL}/api/team?id={team_id}", headers=admin_headers, method='DELETE')
    res_team_del = urllib.request.urlopen(req_team_del, timeout=10)
    print(f"✓ Delete Team Member: HTTP {res_team_del.getcode()}")

    # -------------------------------------------------------------------------
    # 7. WEBSITE SETTINGS CMS AUDIT
    # -------------------------------------------------------------------------
    print("\n6. AUDITING WEBSITE SETTINGS CMS...")
    # Get settings
    req_get_set = urllib.request.Request(f"{BASE_URL}/api/settings", headers=admin_headers)
    res_get_set = urllib.request.urlopen(req_get_set, timeout=10)
    current_settings = json.loads(res_get_set.read().decode('utf-8')).get('settings', {})
    print(f"✓ View Settings: HTTP {res_get_set.getcode()} (Company: {current_settings.get('companyName')})")

    # Super Admin updates settings
    update_set_body = json.dumps({
        'companyName': 'Olive Orange Technologies',
        'tagline': 'Every Problem Has A Solution.',
    }).encode('utf-8')
    req_update_set = urllib.request.Request(f"{BASE_URL}/api/settings", data=update_set_body, headers=admin_headers, method='POST')
    res_update_set = urllib.request.urlopen(req_update_set, timeout=10)
    print(f"✓ Super Admin Update Settings: HTTP {res_update_set.getcode()}")

    # -------------------------------------------------------------------------
    # 8. LEADS / CRM AUDIT
    # -------------------------------------------------------------------------
    print("\n7. AUDITING LEADS / CRM...")
    # View leads
    req_leads = urllib.request.Request(f"{BASE_URL}/api/leads", headers=admin_headers)
    res_leads = urllib.request.urlopen(req_leads, timeout=10)
    leads_data = json.loads(res_leads.read().decode('utf-8')).get('items', [])
    print(f"✓ View Leads: HTTP {res_leads.getcode()} (Retrieved {len(leads_data)} leads)")

    if len(leads_data) > 0:
        lead_sample_id = leads_data[0].get('id')
        # Update lead status
        lead_update_body = json.dumps({'id': lead_sample_id, 'status': 'contacted', 'notes': 'Followed up via phone'}).encode('utf-8')
        req_lead_update = urllib.request.Request(f"{BASE_URL}/api/leads", data=lead_update_body, headers=admin_headers, method='PATCH')
        res_lead_update = urllib.request.urlopen(req_lead_update, timeout=10)
        print(f"✓ Update Lead Status: HTTP {res_lead_update.getcode()}")

    # -------------------------------------------------------------------------
    # 9. RBAC PERMISSIONS AUDIT
    # -------------------------------------------------------------------------
    print("\n8. AUDITING ROLE-BASED ACCESS CONTROL (RBAC)...")
    # Editor trying to access restricted settings (MUST BE 403)
    try:
        req_ed_set = urllib.request.Request(f"{BASE_URL}/api/settings", data=update_set_body, headers=editor_headers, method='POST')
        urllib.request.urlopen(req_ed_set, timeout=10)
        ed_set_allowed = True
    except urllib.error.HTTPError as e:
        ed_set_allowed = False
        print(f"✓ Editor blocked from Settings: HTTP {e.code}")
    assert not ed_set_allowed

    # Editor trying to access team management (MUST BE 403)
    try:
        req_ed_team = urllib.request.Request(f"{BASE_URL}/api/team", data=team_body, headers=editor_headers, method='POST')
        urllib.request.urlopen(req_ed_team, timeout=10)
        ed_team_allowed = True
    except urllib.error.HTTPError as e:
        ed_team_allowed = False
        print(f"✓ Editor blocked from Team Management: HTTP {e.code}")
    assert not ed_team_allowed

    # Editor trying to access CRM leads (MUST BE 403)
    try:
        req_ed_leads = urllib.request.Request(f"{BASE_URL}/api/leads", headers=editor_headers)
        urllib.request.urlopen(req_ed_leads, timeout=10)
        ed_leads_allowed = True
    except urllib.error.HTTPError as e:
        ed_leads_allowed = False
        print(f"✓ Editor blocked from CRM Leads: HTTP {e.code}")
    assert not ed_leads_allowed

    # Operations Admin trying to access settings (MUST BE 403)
    ops_headers = {'Authorization': f'Bearer {ops_token}', 'Content-Type': 'application/json'}
    try:
        req_ops_set = urllib.request.Request(f"{BASE_URL}/api/settings", data=update_set_body, headers=ops_headers, method='POST')
        urllib.request.urlopen(req_ops_set, timeout=10)
        ops_set_allowed = True
    except urllib.error.HTTPError as e:
        ops_set_allowed = False
        print(f"✓ Operations Admin blocked from Super Admin Settings: HTTP {e.code}")
    assert not ops_set_allowed

    # Operations Admin accessing Leads (MUST BE 200)
    req_ops_leads = urllib.request.Request(f"{BASE_URL}/api/leads", headers=ops_headers)
    res_ops_leads = urllib.request.urlopen(req_ops_leads, timeout=10)
    print(f"✓ Operations Admin allowed to view Leads: HTTP {res_ops_leads.getcode()}")

    # -------------------------------------------------------------------------
    # 10. LOGOUT AUDIT
    # -------------------------------------------------------------------------
    print("\n9. AUDITING LOGOUT...")
    req_logout = urllib.request.Request(f"{BASE_URL}/api/auth/logout", headers=admin_headers, method='POST')
    res_logout = urllib.request.urlopen(req_logout, timeout=10)
    print(f"✓ Logout: HTTP {res_logout.getcode()}")

    # Verify session revoked
    try:
        req_me = urllib.request.Request(f"{BASE_URL}/api/auth/me", headers=admin_headers)
        urllib.request.urlopen(req_me, timeout=10)
        revoked = False
    except urllib.error.HTTPError as e:
        revoked = (e.code == 401)
        print(f"✓ Revoked token rejected: HTTP {e.code}")
    assert revoked

    print("\n==================================================")
    print("ALL LIVE CMS VERIFICATION AUDITS COMPLETED SUCCESSFULLY!")
    print("==================================================")

if __name__ == '__main__':
    run_cms_audit()
