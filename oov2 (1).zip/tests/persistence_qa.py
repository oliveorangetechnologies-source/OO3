import urllib.request
import urllib.parse
import urllib.error
import json
import http.cookiejar
import os

BASE_URL = 'http://localhost:3000'

def test_suite():
    print("==================================================")
    print("STEP 6.5 QA: PRODUCTION PERSISTENCE & STORAGE TEST")
    print("==================================================")

    # Setup cookie jar
    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))

    def make_req(path, method='GET', data=None, headers=None):
        url = f"{BASE_URL}{path}"
        body = json.dumps(data).encode('utf-8') if data is not None else None
        h = {'Content-Type': 'application/json', 'User-Agent': 'Persistence-QA'}
        if headers:
            h.update(headers)
        req = urllib.request.Request(url, data=body, headers=h, method=method)
        try:
            res = opener.open(req, timeout=15)
            content = res.read().decode('utf-8')
            return res.getcode(), json.loads(content) if content else {}
        except urllib.error.HTTPError as e:
            content = e.read().decode('utf-8')
            try:
                parsed = json.loads(content)
            except Exception:
                parsed = {'raw': content}
            return e.code, parsed

    # -------------------------------------------------------------------------
    # TEST 0: Health Check
    # -------------------------------------------------------------------------
    code, health_data = make_req('/api/health')
    print(f"\n[Test 0] Health Check: HTTP {code}")
    print(f"Health Response: {json.dumps(health_data)}")
    assert code == 200, f"Expected 200, got {code}"
    assert 'database' in health_data, "Missing database health info"
    assert 'mediaStorage' in health_data, "Missing mediaStorage health info"
    # Ensure no secrets or connection strings leaked
    health_str = json.dumps(health_data).lower()
    assert 'mongodb://' not in health_str, "SECRET LEAK: Mongo URI found in health check!"
    assert 'password' not in health_str, "SECRET LEAK: Password found in health check!"
    print("✓ Health Check passes: properly reports database/storage status without leaking secrets.")

    # -------------------------------------------------------------------------
    # TEST 13 & 14: Admin Login & Session Management
    # -------------------------------------------------------------------------
    print("\n[Test 13] Admin Login:")
    code, login_res = make_req('/api/auth/login', method='POST', data={
        'email': 'admin@oliveorange.tech',
        'password': 'OliveOrange@Admin2026!'
    })
    print(f"Login Response: HTTP {code}, ok={login_res.get('ok')}")
    assert code == 200, f"Expected 200, got {code}: {login_res}"
    assert login_res.get('ok') is True
    admin_token = login_res.get('token')
    assert admin_token is not None
    auth_headers = {'Authorization': f'Bearer {admin_token}'}
    print("✓ Super Admin login successful. Session token acquired.")

    # Editor login for RBAC testing
    code, editor_res = make_req('/api/auth/login', method='POST', data={
        'email': 'editor@oliveorange.tech',
        'password': 'OliveOrange@Editor2026!'
    })
    assert code == 200
    editor_token = editor_res.get('token')
    editor_headers = {'Authorization': f'Bearer {editor_token}'}
    print("✓ Content Editor login successful.")

    # -------------------------------------------------------------------------
    # TEST 1, 2, 3, 4, 5, 6: Blog CMS Lifecycle (Create, Draft, Publish, Edit, Unpublish, Delete)
    # -------------------------------------------------------------------------
    test_slug = 'persistence-verification-article'

    # 1 & 2: Create Draft
    print("\n[Test 1 & 2] Create draft blog post:")
    draft_payload = {
        'title': 'Persistence Verification Article',
        'slug': test_slug,
        'excerpt': 'Testing end-to-end CMS storage persistence lifecycle.',
        'content': 'Comprehensive test content verifying storage mechanics and data integrity.',
        'category': 'AI Solutions & Automation',
        'status': 'draft',
        'author': 'Lead QA Engineer',
    }
    code, create_res = make_req('/api/posts', method='POST', data=draft_payload, headers=editor_headers)
    print(f"Create Draft: HTTP {code}")
    assert code in (200, 201), f"Create failed: {create_res}"
    assert create_res.get('post', {}).get('status') == 'draft'
    print("✓ Draft created successfully.")

    # 3: Publish Blog
    print("\n[Test 3] Publish blog post:")
    code, pub_res = make_req('/api/posts', method='PATCH', data={'slug': test_slug}, headers=editor_headers)
    print(f"Publish: HTTP {code}, status={pub_res.get('post', {}).get('status')}")
    assert code == 200
    assert pub_res.get('post', {}).get('status') == 'published'
    print("✓ Article published successfully.")

    # 4: Edit Blog
    print("\n[Test 4] Edit blog post:")
    code, edit_res = make_req('/api/posts', method='PUT', data={
        'targetSlug': test_slug,
        'title': 'Persistence Verification Article — Updated',
        'excerpt': 'Updated excerpt testing edit persistence.',
    }, headers=editor_headers)
    print(f"Edit: HTTP {code}")
    assert code == 200
    assert edit_res.get('post', {}).get('title') == 'Persistence Verification Article — Updated'
    print("✓ Article edited successfully.")

    # 5: Unpublish Blog
    print("\n[Test 5] Unpublish blog post:")
    code, unpub_res = make_req('/api/posts', method='PATCH', data={'slug': test_slug}, headers=editor_headers)
    print(f"Unpublish: HTTP {code}, status={unpub_res.get('post', {}).get('status')}")
    assert code == 200
    assert unpub_res.get('post', {}).get('status') == 'draft'
    print("✓ Article unpublished back to draft.")

    # 6: Delete Blog
    print("\n[Test 6] Delete blog post:")
    code, del_res = make_req(f'/api/posts?slug={test_slug}', method='DELETE', headers=editor_headers)
    print(f"Delete: HTTP {code}")
    assert code == 200
    print("✓ Article deleted successfully.")

    # -------------------------------------------------------------------------
    # TEST 7: Categories (Create, Edit, Delete)
    # -------------------------------------------------------------------------
    print("\n[Test 7] Create & Edit Category:")
    cat_slug = 'test-cloud-run-category'
    code, cat_create = make_req('/api/categories', method='POST', data={
        'name': 'Cloud Run Engineering',
        'slug': cat_slug,
        'description': 'Persistent Cloud Run container architectures.',
    }, headers=editor_headers)
    print(f"Create Category: HTTP {code}")
    assert code in (200, 201), f"Category create failed: {cat_create}"

    code, cat_edit = make_req('/api/categories', method='PUT', data={
        'targetSlug': cat_slug,
        'name': 'Cloud Run & GCS Architecture',
        'description': 'Updated category description.',
    }, headers=editor_headers)
    print(f"Edit Category: HTTP {code}")
    assert code == 200

    code, cat_del = make_req(f'/api/categories?slug={cat_slug}', method='DELETE', headers=editor_headers)
    print(f"Delete Category: HTTP {code}")
    assert code == 200
    print("✓ Category lifecycle passed.")

    # -------------------------------------------------------------------------
    # TEST 8: Team update according to permissions (RBAC)
    # -------------------------------------------------------------------------
    print("\n[Test 8] Team Management Permissions (RBAC):")
    # Editor MUST be forbidden (403)
    code, ed_team = make_req('/api/team', method='POST', data={'name': 'Forbidden User', 'designation': 'Hacker'}, headers=editor_headers)
    print(f"Editor adding team member: HTTP {code}")
    assert code == 403, f"Expected 403 for Editor, got {code}"

    # Super Admin allowed (201)
    code, adm_team = make_req('/api/team', method='POST', data={'name': 'Valid Officer', 'designation': 'Solutions Architect'}, headers=auth_headers)
    print(f"Admin adding team member: HTTP {code}")
    assert code in (200, 201)
    team_member_id = adm_team.get('member', {}).get('id')
    assert team_member_id is not None

    # Clean up team member
    code, _ = make_req(f'/api/team?id={team_member_id}', method='DELETE', headers=auth_headers)
    assert code == 200
    print("✓ Team permissions strictly enforced (Editor 403, Admin 201).")

    # -------------------------------------------------------------------------
    # TEST 9: Settings update according to permissions (RBAC)
    # -------------------------------------------------------------------------
    print("\n[Test 9] Settings Permissions (RBAC):")
    # Editor forbidden (403)
    code, _ = make_req('/api/settings', method='POST', data={'tagline': 'Hacked'}, headers=editor_headers)
    assert code == 403, f"Expected 403 for editor modifying settings, got {code}"

    # Super Admin allowed (200)
    code, set_res = make_req('/api/settings', method='POST', data={'tagline': 'Every Problem Has A Solution.'}, headers=auth_headers)
    assert code == 200
    print("✓ Settings permissions strictly enforced (Editor 403, Super Admin 200).")

    # -------------------------------------------------------------------------
    # TEST 10 & 11: Contact & Demo Form Submissions + Validations + Honeypot
    # -------------------------------------------------------------------------
    print("\n[Test 10 & 11] Public Forms (Contact & Demo):")

    # 10.1 Valid Contact Submission
    code, contact_res = make_req('/api/contact', method='POST', data={
        'name': 'Pooja Patel',
        'email': 'pooja.patel@gujaratindustries.com',
        'phone': '+91 98765 43210',
        'company': 'Gujarat Engineering Ltd',
        'message': 'We need an automated CRM pipeline and ERP integration.',
    })
    print(f"Valid Contact: HTTP {code}, ok={contact_res.get('ok')}")
    assert code == 200 and contact_res.get('ok') is True
    contact_id = contact_res.get('id')

    # 10.2 Invalid Contact Submission (Missing Name & Contact info)
    code, inv_res = make_req('/api/contact', method='POST', data={'name': ''})
    print(f"Invalid Contact: HTTP {code}")
    assert code == 400

    # 10.3 Honeypot Spam Submission
    code, honey_res = make_req('/api/contact', method='POST', data={
        'name': 'Bot Spammer',
        'email': 'spammer@botnet.ru',
        'honeypot': 'bot-filled-value',
    })
    print(f"Honeypot Contact: HTTP {code}, spam={honey_res.get('spam')}")
    assert code == 200 and honey_res.get('spam') is True

    # 11.1 Valid Demo Submission
    code, demo_res = make_req('/api/demo', method='POST', data={
        'name': 'Vikram Mehta',
        'email': 'vikram@mehtaenterprises.in',
        'phone': '+91 99887 76655',
        'company': 'Mehta Textiles',
        'message': 'Requesting walkthrough of warehouse inventory ERP module.',
    })
    print(f"Valid Demo: HTTP {code}, ok={demo_res.get('ok')}")
    assert code == 200 and demo_res.get('ok') is True

    # -------------------------------------------------------------------------
    # TEST 12: Lead Retrieval & RBAC Protection
    # -------------------------------------------------------------------------
    print("\n[Test 12] Lead Retrieval CRM API:")
    # Public request forbidden (401 without cookie/bearer)
    clean_opener = urllib.request.build_opener()
    clean_req = urllib.request.Request(f"{BASE_URL}/api/leads", headers={'User-Agent': 'Persistence-QA'})
    try:
        clean_res = clean_opener.open(clean_req, timeout=15)
        clean_code = clean_res.getcode()
    except urllib.error.HTTPError as e:
        clean_code = e.code
    assert clean_code == 401, f"Expected 401 unauthenticated, got {clean_code}"

    # Editor forbidden (403)
    code, _ = make_req('/api/leads', headers=editor_headers)
    assert code == 403, f"Expected 403 for Editor on CRM leads, got {code}"

    # Admin retrieval allowed (200)
    code, leads_res = make_req('/api/leads', headers=auth_headers)
    assert code == 200
    leads_list = leads_res.get('items', [])
    print(f"Admin retrieved {len(leads_list)} leads.")
    assert len(leads_list) > 0
    # Verify our submitted lead is present
    found = any(l.get('id') == contact_id or l.get('email') == 'pooja.patel@gujaratindustries.com' for l in leads_list)
    assert found, "Submitted contact lead was not found in retrieved CRM list!"
    print("✓ Leads retrieved successfully with strict RBAC enforcement.")

    # -------------------------------------------------------------------------
    # TEST 14: Admin Logout
    # -------------------------------------------------------------------------
    print("\n[Test 14] Admin Logout & Session Invalidation:")
    code, logout_res = make_req('/api/auth/logout', method='POST', headers=auth_headers)
    assert code == 200

    # Verify session revoked
    code, me_res = make_req('/api/auth/me', headers=auth_headers)
    print(f"Subsequent auth check with revoked token: HTTP {code}")
    assert code == 401, f"Revoked token should yield 401, got {code}"
    print("✓ Session successfully revoked upon logout.")

    print("\n==================================================")
    print("ALL 14 PRODUCTION PERSISTENCE & QA TESTS PASSED!")
    print("==================================================")

if __name__ == '__main__':
    test_suite()
