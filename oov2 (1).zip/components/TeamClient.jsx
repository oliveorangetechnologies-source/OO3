'use client'
import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Link from 'next/link'
import {
  Users,
  Linkedin,
  ArrowRight,
  Sparkles,
  Award,
  CheckCircle2,
  Briefcase,
  GraduationCap,
  X as XIcon,
  Send,
  MessageSquare,
  Mail,
  Phone,
} from 'lucide-react'
import { toast } from 'sonner'
import HeaderClient from '@/components/HeaderClient'
import FooterCTA from '@/components/FooterCTA'
import DemoModal from '@/components/DemoModal'
import { TEAM_MEMBERS } from '@/lib/team-data'

const DEPARTMENTS = ['All', 'Leadership', 'Engineering', 'Product & Design', 'Consulting']

const OPEN_POSITIONS = [
  {
    title: 'Full-Stack Developer (Web & Cloud)',
    type: 'Full-time / Contract',
    location: 'Remote / Flexible',
    exp: 'Relevant Experience',
    desc: 'Build resilient web applications, modern responsive interfaces, and API integrations.',
  },
  {
    title: 'AI Solutions & Automation Engineer',
    type: 'Full-time / Contract',
    location: 'Remote / Flexible',
    exp: 'Relevant Experience',
    desc: 'Develop practical AI automation, workflow integrations, and conversational agents.',
  },
  {
    title: 'Business Solutions Consultant',
    type: 'Full-time / Contract',
    location: 'Remote / Flexible',
    exp: 'Relevant Experience',
    desc: 'Analyse business workflows and design customized digital solutions for operational efficiency.',
  },
  {
    title: 'UI/UX & Creative Designer',
    type: 'Full-time / Contract',
    location: 'Remote / Flexible',
    exp: 'Relevant Experience',
    desc: 'Create clean, intuitive digital experiences, design systems, and brand assets.',
  },
]

export default function TeamClient({ initialMembers }) {
  const [activeDept, setActiveDept] = useState('All')
  const [teamList, setTeamList] = useState(
    Array.isArray(initialMembers) && initialMembers.length > 0 ? initialMembers : TEAM_MEMBERS
  )
  const [selectedMember, setSelectedMember] = useState(null)
  const [demoOpen, setDemoOpen] = useState(false)
  const [applyModal, setApplyModal] = useState({ open: false, role: '' })
  const [applyForm, setApplyForm] = useState({ name: '', email: '', phone: '', portfolio: '', note: '' })
  const [submittingApply, setSubmittingApply] = useState(false)

  const filteredMembers =
    activeDept === 'All'
      ? teamList
      : teamList.filter((m) => (m.department || m.designation || '').toLowerCase().includes(activeDept.toLowerCase()))

  const handleApply = async (e) => {
    e.preventDefault()
    if (!applyForm.name || !applyForm.phone) {
      toast.error('Please provide name and phone/WhatsApp number.')
      return
    }
    setSubmittingApply(true)
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...applyForm,
          type: 'career_application',
          role: applyModal.role,
          message: `Career Application for ${applyModal.role}. Portfolio: ${applyForm.portfolio}. Note: ${applyForm.note}`,
        }),
      })
      const data = await res.json()
      if (data?.ok) {
        toast.success(`Application submitted for ${applyModal.role}! Our team will get in touch.`)
        setApplyModal({ open: false, role: '' })
        setApplyForm({ name: '', email: '', phone: '', portfolio: '', note: '' })
      } else {
        toast.error('Failed to submit application. Please reach us at oliveorangetechnologies@gmail.com')
      }
    } catch {
      toast.error('Network error. Please email oliveorangetechnologies@gmail.com')
    }
    setSubmittingApply(false)
  }

  return (
    <main className="relative bg-white text-neutral-900 overflow-x-hidden">
      <HeaderClient />

      {/* HERO */}
      <section className="relative pt-36 pb-16 sm:pt-44">
        <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-24 -left-24 h-[420px] w-[420px] rounded-full bg-brand-200 opacity-60 blob" />
          <div
            className="absolute top-10 -right-20 h-[520px] w-[520px] rounded-full bg-orange-100 opacity-80 blob"
            style={{ animationDelay: '-4s' }}
          />
          <div className="absolute inset-0 grid-pattern opacity-40" />
        </div>
        <div className="container max-w-5xl mx-auto text-center px-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100 text-brand-700 text-xs font-semibold uppercase tracking-widest">
            <Users className="h-3.5 w-3.5" /> Team &amp; Talent
          </div>
          <h1 className="font-display text-4xl sm:text-6xl font-bold mt-4 tracking-tight leading-[1.08] text-neutral-900">
            People who turn problems{' '}
            <span className="bg-gradient-to-r from-brand-500 via-orange-500 to-amber-500 bg-clip-text text-transparent">
              into digital solutions.
            </span>
          </h1>
          <p className="text-neutral-600 text-lg mt-5 max-w-2xl mx-auto leading-relaxed">
            We analyse your business problems and build the right digital solution. Every Problem Has A Solution.
          </p>
        </div>
      </section>

      {/* DEPARTMENT FILTER TABS */}
      {TEAM_MEMBERS.length > 0 && (
        <section className="pb-8">
          <div className="container max-w-6xl mx-auto px-4">
            <div className="flex items-center justify-center flex-wrap gap-2 p-1.5 bg-neutral-100/80 rounded-2xl max-w-2xl mx-auto">
              {DEPARTMENTS.map((dept) => {
                const active = activeDept === dept
                return (
                  <button
                    key={dept}
                    onClick={() => setActiveDept(dept)}
                    className={`px-4 py-2 text-xs font-medium rounded-xl transition-all whitespace-nowrap ${
                      active
                        ? 'bg-white text-neutral-900 shadow-sm font-semibold'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    {dept}
                  </button>
                )
              })}
            </div>
          </div>
        </section>
      )}

      {/* TEAM DIRECTORY / TRANSPARENT ARCHITECTURE */}
      <section className="py-8 pb-16">
        <div className="container max-w-6xl mx-auto px-4">
          {filteredMembers.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredMembers.map((member, i) => (
                <motion.div
                  key={member.slug || i}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="rounded-3xl p-6 bg-white border border-neutral-200/80 shadow-sm flex flex-col justify-between"
                >
                  <div>
                    <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-600 text-white flex items-center justify-center font-display text-lg font-bold shadow-sm">
                      {member.name ? member.name.charAt(0) : 'O'}
                    </div>
                    <h3 className="font-display font-bold text-base text-neutral-900 mt-4">{member.name}</h3>
                    <div className="text-xs font-medium text-brand-600 mt-0.5">{member.role}</div>
                    <p className="text-xs text-neutral-600 mt-3 line-clamp-3 leading-relaxed">{member.bio}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="rounded-3xl bg-neutral-50 border border-neutral-200/80 p-8 sm:p-12 text-center max-w-2xl mx-auto">
              <div className="h-12 w-12 rounded-2xl bg-brand-100 text-brand-700 flex items-center justify-center mx-auto mb-4">
                <Users className="h-6 w-6" />
              </div>
              <h3 className="font-display font-bold text-xl text-neutral-900">
                Team Profiles Architecture
              </h3>
              <p className="text-neutral-600 text-sm mt-3 leading-relaxed">
                Official team profiles and verified leadership disclosures will be published here upon official release.
                In the meantime, connect directly with our solutions team to discuss your business requirements.
              </p>
              <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                <a
                  href="https://wa.me/919624689335"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#25D366] text-white text-xs font-semibold hover:opacity-90 transition"
                >
                  <MessageSquare className="h-3.5 w-3.5" /> WhatsApp: +91 96246 89335
                </a>
                <a
                  href="mailto:oliveorangetechnologies@gmail.com"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-neutral-900 text-white text-xs font-semibold hover:bg-black transition"
                >
                  <Mail className="h-3.5 w-3.5" /> Email Us
                </a>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* HOW WE WORK */}
      <section className="py-16 bg-neutral-50/80 border-y border-neutral-200/60">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">
              Our Approach
            </div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold mt-3 text-neutral-900">
              How we approach every problem
            </h2>
            <p className="text-neutral-600 text-sm mt-2">
              Every Problem Has A Solution. We analyse your business problems and build the right digital solution.
            </p>
          </div>

          <div className="grid sm:grid-cols-3 gap-6 mt-12">
            <div className="rounded-3xl bg-white p-7 border border-neutral-200/80 shadow-sm">
              <div className="h-10 w-10 rounded-xl bg-brand-100 text-brand-600 flex items-center justify-center font-bold text-sm">
                01
              </div>
              <h3 className="font-display font-bold text-lg mt-4 text-neutral-900">
                Problem Analysis
              </h3>
              <p className="text-neutral-600 text-sm mt-2 leading-relaxed">
                We begin by understanding your exact business bottlenecks, manual steps, and workflow inefficiencies before proposing any technology.
              </p>
            </div>
            <div className="rounded-3xl bg-white p-7 border border-neutral-200/80 shadow-sm">
              <div className="h-10 w-10 rounded-xl bg-brand-100 text-brand-600 flex items-center justify-center font-bold text-sm">
                02
              </div>
              <h3 className="font-display font-bold text-lg mt-4 text-neutral-900">
                The Right Digital Solution
              </h3>
              <p className="text-neutral-600 text-sm mt-2 leading-relaxed">
                We design and build the right digital solution tailored to your operational scale, whether that is web, automation, AI, or custom software.
              </p>
            </div>
            <div className="rounded-3xl bg-white p-7 border border-neutral-200/80 shadow-sm">
              <div className="h-10 w-10 rounded-xl bg-brand-100 text-brand-600 flex items-center justify-center font-bold text-sm">
                03
              </div>
              <h3 className="font-display font-bold text-lg mt-4 text-neutral-900">
                Delivery &amp; Support
              </h3>
              <p className="text-neutral-600 text-sm mt-2 leading-relaxed">
                We ensure seamless implementation, user onboarding, and ongoing maintenance to keep your systems running smoothly.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CAREERS / OPPORTUNITIES */}
      <section className="py-20">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">
                Opportunities
              </div>
              <h2 className="font-display text-3xl sm:text-4xl font-bold mt-3 text-neutral-900">
                Work with Olive Orange Technologies
              </h2>
              <p className="text-neutral-600 text-sm mt-2 max-w-xl">
                Passionate about solving real-world business challenges through technology? Explore open opportunities or send your portfolio.
              </p>
            </div>
            <a
              href="mailto:oliveorangetechnologies@gmail.com"
              className="inline-flex items-center gap-2 text-sm font-semibold text-brand-600 hover:text-brand-700 transition"
            >
              Email resume directly <ArrowRight className="h-4 w-4" />
            </a>
          </div>

          <div className="space-y-4">
            {OPEN_POSITIONS.map((pos) => (
              <div
                key={pos.title}
                className="rounded-3xl bg-white p-6 border border-neutral-200/80 hover:border-brand-300 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 transition"
              >
                <div>
                  <h3 className="font-display font-bold text-lg text-neutral-900">{pos.title}</h3>
                  <div className="flex items-center gap-2 text-xs text-neutral-500 mt-1">
                    <span>{pos.type}</span>
                    <span aria-hidden="true">·</span>
                    <span>{pos.location}</span>
                    <span aria-hidden="true">·</span>
                    <span>{pos.exp}</span>
                  </div>
                  <p className="text-xs text-neutral-600 mt-2 max-w-2xl">{pos.desc}</p>
                </div>
                <button
                  onClick={() => setApplyModal({ open: true, role: pos.title })}
                  className="px-5 py-2.5 rounded-full bg-neutral-900 hover:bg-black text-white text-xs font-semibold whitespace-nowrap transition self-start md:self-center"
                >
                  Apply for Role
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* APPLICATION MODAL */}
      <AnimatePresence>
        {applyModal.open && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-lg bg-white rounded-3xl p-6 sm:p-8 shadow-xl"
            >
              <button
                onClick={() => setApplyModal({ open: false, role: '' })}
                className="absolute top-5 right-5 p-2 rounded-full hover:bg-neutral-100 text-neutral-500"
                aria-label="Close modal"
              >
                <XIcon className="h-5 w-5" />
              </button>

              <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">
                Career Application
              </div>
              <h3 className="font-display text-2xl font-bold mt-2 text-neutral-900">Apply: {applyModal.role}</h3>
              <p className="text-xs text-neutral-500 mt-1">
                Tell us about your background and code.
              </p>

              <form onSubmit={handleApply} className="mt-5 space-y-3">
                <input
                  required
                  value={applyForm.name}
                  onChange={(e) => setApplyForm({ ...applyForm, name: e.target.value })}
                  placeholder="Your Full Name*"
                  className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                />
                <div className="grid sm:grid-cols-2 gap-3">
                  <input
                    type="email"
                    value={applyForm.email}
                    onChange={(e) => setApplyForm({ ...applyForm, email: e.target.value })}
                    placeholder="Email Address"
                    className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                  />
                  <input
                    required
                    value={applyForm.phone}
                    onChange={(e) => setApplyForm({ ...applyForm, phone: e.target.value })}
                    placeholder="Phone / WhatsApp*"
                    className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                  />
                </div>
                <input
                  value={applyForm.portfolio}
                  onChange={(e) => setApplyForm({ ...applyForm, portfolio: e.target.value })}
                  placeholder="Portfolio / LinkedIn / GitHub URL"
                  className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                />
                <textarea
                  rows={3}
                  value={applyForm.note}
                  onChange={(e) => setApplyForm({ ...applyForm, note: e.target.value })}
                  placeholder="Tell us about what you build and your experience"
                  className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                />

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setApplyModal({ open: false, role: '' })}
                    className="px-4 py-2 text-xs font-semibold text-neutral-600 hover:text-neutral-900"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submittingApply}
                    className="px-5 py-2.5 rounded-full bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold shadow-glow disabled:opacity-60 transition"
                  >
                    {submittingApply ? 'Submitting…' : 'Submit Application'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <FooterCTA />
      <DemoModal open={demoOpen} onClose={() => setDemoOpen(false)} />
    </main>
  )
}
